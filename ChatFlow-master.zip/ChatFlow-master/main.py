import sys
import discord
from discord.ext import commands

import Cogs.code_completion

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='$', intents=intents)

# Add the CodeCompletion cog
bot.add_cog(Cogs.code_completion.CodeCompletion(bot))


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}', file=sys.stderr)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name="Rust"))


bot.run('MTE1MzcyMzU2MjQxOTU3Mjc5Ng.G1h-YE.ng9ncc4BD6UN22PiQlRagX5_wrY0SBUNdvsozs')
