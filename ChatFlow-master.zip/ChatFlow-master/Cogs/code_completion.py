import discord
from discord.ext import commands

import api_wrapper


class CodeCompletion(commands.Cog):
    def __init__(self, bot):
        self.bot: discord.Client = bot
        self.NAS: api_wrapper.NAS = api_wrapper.NAS()

    @discord.slash_command(description="Responds with a chatflow ai message response.", name="ask")
    async def ask(self: discord.Client, ctx: discord.ApplicationContext, question: str):
        message: discord.Message = await ctx.respond("One moment...")
        completion: str = self.NAS.get_completion(question=question)
        print(f"Question completed: {question}, was asked by {ctx.author}. Completion: {completion}")
        if completion != "":
            return await message.edit_original_response(content=completion)
        return await message.edit_original_response(content="Something went wrong...")

    @discord.slash_command(description="Displays the current chatflow context.", name="context")
    async def get_context(self: discord.Client, ctx: discord.ApplicationContext):
        return await ctx.respond(self.NAS.get_context())
