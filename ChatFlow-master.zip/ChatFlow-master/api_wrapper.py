import httpx


class NAS:
    def __init__(self, base_url="https://apps.newaisolutions.com/api/v1"):
        self.bearer = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhcHNzb3V6YTIyQGdtYWlsLmNvbSIsInR5cGUiOiJhcHAtYXV0aCIsImV4cCI6MTY5NTE4MzIwM30.WyLdrraGXlx85QYqkaNFeGUWhXqKJpc7fzH2SOBIL8Y"
        self.base_url = base_url
        self.session: httpx.Client = httpx.Client()

    def get_context(self, text):
        endpoint = "/docs/search"
        url = f"{self.base_url}{endpoint}"
        data = {
            "text": text,
            "app_key": "61866002"
        }
        try:
            headers = {
                "pluginmode": "false",
                "Authorization": self.bearer
            }
            response = self.session.post(url, timeout=30, json=data, headers=headers)
            response.raise_for_status()
            result = response.json()
            context = result["docs"][0]
        except httpx.HTTPError as e:
            print(f"Error: {e}")
            context = ""
        return context

    def get_completion(self, question: str):
        endpoint = "/chat/completions"
        url = f"{self.base_url}{endpoint}"
        data = {
            "context": self.get_context(question),
            "question": question,
        }

        try:
            headers = {
                "Authorization": self.bearer
            }
            response = self.session.post(url, timeout=30, json=data, headers=headers)
            response.raise_for_status()
            result = response.json()
            answer = result.get("thoughts", {}).get("answer", "")
        except httpx.HTTPError as e:
            print(f"Error: {e}")
            answer = ""

        return answer
